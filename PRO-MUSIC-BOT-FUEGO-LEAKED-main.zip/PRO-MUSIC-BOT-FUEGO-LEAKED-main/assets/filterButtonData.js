/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 The Extremez
 */

module.exports = [
  /////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////
  { customId: "eightD", label: "8-D", style: "SECONDARY" },
  { customId: "soft", label: "SOFT", style: "SECONDARY" },
  { customId: "speed", label: "SPEED", style: "SECONDARY" },
  { customId: "karaoke", label: "KARAOKE", style: "SECONDARY" },
  /////////////////////////////////////////////////////////////
  { customId: "nightcore", label: "NIGHTCR", style: "SECONDARY" },
  { customId: "pop", label: "POP", style: "SECONDARY" },
  { customId: "vaporwave", label: "VAPOR", style: "SECONDARY" },
  { customId: "bass", label: "BASS", style: "SECONDARY" },
  /////////////////////////////////////////////////////////////
  { customId: "party", label: "PARTY", style: "SECONDARY" },
  { customId: "earrape", label: "EARRAPE", style: "SECONDARY" },
  { customId: "equalizer", label: "EQ", style: "SECONDARY" },
  { customId: "electronic", label: "ELEC", style: "SECONDARY" },
  /////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////

  /////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////
  { customId: "radio", label: "RADIO", style: "SECONDARY" },
  { customId: "treblebass", label: "TRIBOSS", style: "SECONDARY" },
  { customId: "tremlo", label: "TREM", style: "SECONDARY" },
  { customId: "vibrato", label: "VIB", style: "SECONDARY" },
  /////////////////////////////////////////////////////////////
  { customId: "china", label: "CHINA", style: "SECONDARY" },
  { customId: "chimpunk", label: "CHIIMP", style: "SECONDARY" },
  { customId: "darthvader", label: "DART", style: "SECONDARY" },
  { customId: "daycore", label: "DAYCR", style: "SECONDARY" },
  /////////////////////////////////////////////////////////////
  { customId: "doubletime", label: "2xFAST", style: "SECONDARY" },
  { customId: "pitch", label: "PITCH", style: "SECONDARY" },
  { customId: "rate", label: "RATE", style: "SECONDARY" },
  { customId: "slow", label: "SLOWW", style: "SECONDARY" },
  /////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////

  /////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////
  { customId: "previous", label: "PREV", style: "PRIMARY" },
  {
    customId: "clear",
    label: "CLEAR ACTIVE FILTER",
    style: "DANGER",
  },
  { customId: "next", label: "NEXT", style: "PRIMARY" },
  /////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////////
];
