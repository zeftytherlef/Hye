/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 The Extremez
 */

module.exports = {
  lofi_radios: {
    beats: "https://www.youtube.com/watch?v=jfKfPfyJRdk&pp",
    bolly: "https://www.youtube.com/watch?v=RRb5XV993W0",
    synth: "https://www.youtube.com/watch?v=4xDzrJKXOOY",
    japanese: "https://www.youtube.com/watch?v=PiDkx92Y6EU",
  },
  english_radios: {
    hits: "https://www.youtube.com/watch?v=HQtFR3mhzOY&pp",
    EDM: "https://www.youtube.com/watch?v=whACSpi2zQ8",
    chill: "https://www.youtube.com/watch?v=IkmLXvBfVv0&pp",
    ncs: "https://www.youtube.com/watch?v=7tNtU5XFwrU&pp",
    phonk: "https://www.youtube.com/watch?v=S6helKOW5P0&pp",
    rap: "https://www.youtube.com/watch?v=0MOkLkTP-Jk&pp",
    hiphop: "https://www.youtube.com/watch?v=05689ErDUdM&pp",
    aggressive: "https://www.youtube.com/watch?v=1y2R_i2OeFw",
  },
  hindi_radios: {
    lofi: "https://www.youtube.com/watch?v=RRb5XV993W0",
  },
};
